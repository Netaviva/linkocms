$App.admincp = function(){
	Linko.tabilize($('ul.tabs li a'), $('ul.tabs-content li'));
}