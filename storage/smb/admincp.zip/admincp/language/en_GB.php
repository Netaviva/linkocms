<?php

defined('LINKO') or exit;

return array(
    'rules' => array(),
    'translation' => array(
        'admincp.login_to_admincp' => 'Login to AdminCP'
    )
        )
?>