<?php

return array
(
    'translation' => array
    (
        'activity.write_something'=> 'Write Something?',
        'activity.post-feed' => 'Post To Feed',
        'make-comment' => 'Write a comment',
        'activity.whats_on_your_mind' => 'What\'s on your mind?',
    )
);