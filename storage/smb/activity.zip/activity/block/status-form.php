<?php

class Activity_Block_Status_Form extends Linko_Controller
{
    public function main()
    {

    }
}

?>